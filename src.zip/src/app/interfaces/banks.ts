
export interface IBanks {
    id?: number,
    ref_code: string,
    name: string,
    short_name: string,
    created_at?: Date,
    updated_at?: Date
}